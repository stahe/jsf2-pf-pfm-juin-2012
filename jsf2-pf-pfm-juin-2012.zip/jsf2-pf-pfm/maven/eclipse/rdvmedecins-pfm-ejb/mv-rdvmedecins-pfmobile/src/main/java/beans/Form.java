package beans;

import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import rdvmedecins.jpa.Client;
import rdvmedecins.jpa.Creneau;
import rdvmedecins.jpa.Medecin;
import rdvmedecins.metier.entites.AgendaMedecinJour;
import rdvmedecins.metier.entites.CreneauMedecinJour;
import rdvmedecins.metier.service.IMetierLocal;
import utils.Messages;

@Named(value = "form")
@SessionScoped
public class Form implements Serializable {

  public Form() {
  }
  // bean Application
  @Inject
  private Application application;
  private IMetierLocal metier;
  // cache de la session
  private List<Medecin> medecins;
  private List<Client> clients;
  private Map<Long, Medecin> hMedecins = new HashMap<Long, Medecin>();
  private Map<Long, Client> hClients = new HashMap<Long, Client>();
  // modèle
  private Long idMedecin;
  private Date jour = new Date();
  private String strJour;
  private Boolean form1Rendered;
  private Boolean form2Rendered;
  private Boolean form3Rendered;
  private Boolean erreurRendered;
  private String form2Titre;
  private String form3Titre;
  private AgendaMedecinJour agendaMedecinJour;
  private Long idCreneauChoisi;
  private Medecin medecin;
  private Long idClient;
  private CreneauMedecinJour creneauChoisi;
  private List<Erreur> erreurs;
  private Boolean erreurInit = false;
  private String action;
  private String locale = "fr";
  private String msgErreurDate = "";
  private SimpleDateFormat dateFormatter;
  private Boolean erreurDate;
  
  @PostConstruct
  private void init() {
    // au départ pas d'erreur
    erreurInit = false;
    // le formatage des dates
    dateFormatter = new SimpleDateFormat(Messages.getMessage(null, "format.date", null).getSummary());
    dateFormatter.setLenient(false);
    // le jour courant
    strJour = dateFormatter.format(jour);
    // on récupère la couche métier
    metier = application.getMetier();
    // on met les médecins et les clients en cache
    try {
      medecins = metier.getAllMedecins();
      clients = metier.getAllClients();
    } catch (Throwable th) {
      // on note l'erreur
      erreurInit = true;
      prepareVueErreur(th);
      return;
    }
    // vérification des listes
    if (medecins.size() == 0) {
      // on note l'erreur
      erreurInit = true;
      erreurs = new ArrayList<Erreur>();
      erreurs.add(new Erreur("", "La liste des médecins est vide"));
    }
    if (clients.size() == 0) {
      // on note l'erreur
      erreurInit = true;
      erreurs = new ArrayList<Erreur>();
      erreurs.add(new Erreur("", "La liste des clients est vide"));
    }
    // erreur ?
    if (erreurInit) {
      // la vue des erreurs est affichée
      setForms(false, false, false, true);
      return;
    }

    // les dictionnaires
    for (Medecin m : medecins) {
      hMedecins.put(m.getId(), m);
    }
    for (Client c : clients) {
      hClients.put(c.getId(), c);
    }
    // la vue 1
    setForms(true, false, false, false);
  }

  // liste des médecins
  public List<Medecin> getMedecins() {
    return medecins;
  }

  // liste des clients
  public List<Client> getClients() {
    return clients;
  }

  // agenda
  public String getAgenda() {
    try {
      // on vérifie le jour
      jour = dateFormatter.parse(strJour);
      // pas d'erreur
      erreurDate=false;
      msgErreurDate = "";
      // on crée l'agenda
      return getAgenda(jour);
    } catch (ParseException ex) {
      // msg d'erreur
      erreurDate=true;
      msgErreurDate = Messages.getMessage(null, "form1.date.invalide", null).getSummary();
      // vue1      
      setForms(true, false, false, false);
      return "pm:vue1";
    }
  }

  // agenda
  public String getAgenda(Date jour) {
    // aucun créneau choisi pour l'instant
    creneauChoisi = null;
    try {
      // on récupère le médecin choisi
      medecin = hMedecins.get(idMedecin);
      // titre formulaire 2
      form2Titre = Messages.getMessage(null, "form2.titre", new Object[]{medecin.getTitre(), medecin.getPrenom(), medecin.getNom(), new SimpleDateFormat("dd MMM yyyy").format(jour)}).getSummary();
      // l'agenda du médecin pour un jour donné
      agendaMedecinJour = metier.getAgendaMedecinJour(medecin, jour);
      // on affiche la vue 2
      setForms(false, true, false, false);
      return "pm:vue2";
    } catch (Throwable th) {
      System.out.println(th);
      // vue des erreurs
      prepareVueErreur(th);
      return "pm:vueErreurs";
    }
  }

  // action sur RV
  public String action() {
    // on recherche le créneau dans l'agenda
    int i = 0;
    Boolean trouvé = false;
    while (!trouvé && i < agendaMedecinJour.getCreneauxMedecinJour().length) {
      if (agendaMedecinJour.getCreneauxMedecinJour()[i].getCreneau().getId() == idCreneauChoisi) {
        trouvé = true;
      } else {
        i++;
      }
    }
    // a-t-on trouvé ?
    if (!trouvé) {
      // c'est bizarre - on réaffiche form2
      setForms(false, true, false, false);
      return "pm:vue2";
    } else {
      creneauChoisi = agendaMedecinJour.getCreneauxMedecinJour()[i];
    }
    // on a trouvé
    // selon l'action désirée
    if (creneauChoisi.getRv() == null) {
      return reserver();
    } else {
      return supprimer();
    }
  }

  // réservation
  public String reserver() {
    try {
      // titre formulaire 3
      form3Titre = Messages.getMessage(null, "form3.titre", new Object[]{medecin.getTitre(), medecin.getPrenom(), medecin.getNom(), new SimpleDateFormat("dd MMM yyyy").format(jour),
                creneauChoisi.getCreneau().getHdebut(), creneauChoisi.getCreneau().getMdebut(), creneauChoisi.getCreneau().getHfin(), creneauChoisi.getCreneau().getMfin()}).getSummary();
      // on affiche le formulaire 3
      setForms(false, false, true, false);
      return "pm:vue3";
    } catch (Throwable th) {
      // vue erreurs
      prepareVueErreur(th);
      return "pm:vueErreurs";
    }
  }

  public String supprimer() {
    try {
      // suppression d'un Rdv
      metier.supprimerRv(creneauChoisi.getRv());
      // on remet à jour l'agenda
      agendaMedecinJour = metier.getAgendaMedecinJour(medecin, jour);
      // on affiche form2
      setForms(false, true, false, false);
      return "pm:vue2";
    } catch (Throwable th) {
      // vue erreurs
      prepareVueErreur(th);
      return "pm:vueErreurs";
    }
  }

  // validation Rv
  public String validerRv() {
    try {
      // on récupère une instance du créneau choisi
      Creneau creneau = metier.getCreneauById(idCreneauChoisi);
      // on ajoute le Rv
      metier.ajouterRv(jour, creneau, hClients.get(idClient));
      // on remet à jour l'agenda
      agendaMedecinJour = metier.getAgendaMedecinJour(medecin, jour);
      // on affiche form2
      setForms(false, true, false, false);
      return "pm:vue2";
    } catch (Throwable th) {
      // vue erreurs
      prepareVueErreur(th);
      return "pm:vueErreurs";
    }
  }

  public String showVue1() {
    // vue1
    setForms(true, false, false, false);
    return "pm:vue1?reverse=true";
  }

  public String showVue2() {
    // vue2
    setForms(false, true, false, false);
    return "pm:vue2?reverse=true";
  }

  public String getPreviousAgenda() {
    // on passe au jour précédent
    Calendar cal = Calendar.getInstance();
    cal.setTime(jour);
    cal.add(Calendar.DAY_OF_YEAR, -1);
    jour = cal.getTime();
    // agenda
    System.out.println(dateFormatter.format(jour));
    return getAgenda(jour);
  }

  public String getNextAgenda() {
    // on passe au jour suivant
    Calendar cal = Calendar.getInstance();
    cal.setTime(jour);
    cal.add(Calendar.DAY_OF_YEAR, 1);
    jour = cal.getTime();
    System.out.println(dateFormatter.format(jour));
    // agenda
    return getAgenda(jour);
  }

  // agenda aujourd'hui
  public String getTodayAgenda() {
    jour = new Date();
    // agenda
    System.out.println(dateFormatter.format(jour));
    return getAgenda(jour);
  }

  public String configurer(){
    // après configuration - on réaffiche vue1
    redirect();
    return null;
  }
  
  private void redirect() {
    // on redirige le client vers la servlet
    ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
    try {
      ctx.redirect(ctx.getRequestContextPath());
    } catch (IOException ex) {
      Logger.getLogger(Form.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

  // affichage vue
  private void setForms(Boolean form1Rendered, Boolean form2Rendered, Boolean form3Rendered, Boolean erreurRendered) {
    this.form1Rendered = form1Rendered;
    this.form2Rendered = form2Rendered;
    this.form3Rendered = form3Rendered;
    this.erreurRendered = erreurRendered;
  }

  // préparation vueErreur
  private void prepareVueErreur(Throwable th) {
    // on crée la liste des erreurs
    erreurs = new ArrayList<Erreur>();
    erreurs.add(new Erreur(th.getClass().getName(), th.getMessage()));
    while (th.getCause() != null) {
      th = th.getCause();
      erreurs.add(new Erreur(th.getClass().getName(), th.getMessage()));
    }
// la vue des erreurs est affichée
    setForms(false, false, false, true);
  }

  // getters et setters
  public Date getJour() {
    return jour;
  }

  public void setJour(Date jour) {
    this.jour = jour;
  }

  public Long getIdMedecin() {
    return idMedecin;
  }

  public void setIdMedecin(Long idMedecin) {
    this.idMedecin = idMedecin;
  }

  public Boolean getForm1Rendered() {
    return form1Rendered;
  }

  public Boolean getForm2Rendered() {
    return form2Rendered;
  }

  public Boolean getForm3Rendered() {
    return form3Rendered;
  }

  public String getForm2Titre() {
    return form2Titre;
  }

  public AgendaMedecinJour getAgendaMedecinJour() {
    return agendaMedecinJour;
  }

  public String getForm3Titre() {
    return form3Titre;
  }

  public Long getIdClient() {
    return idClient;
  }

  public void setIdClient(Long idClient) {
    this.idClient = idClient;
  }

  public Boolean getErreurRendered() {
    return erreurRendered;
  }

  public List<Erreur> getErreurs() {
    return erreurs;
  }

  public void setAction(String action) {
    this.action = action;
  }

  public void setCreneauChoisi(CreneauMedecinJour creneauChoisi) {
    this.creneauChoisi = creneauChoisi;
  }

  public CreneauMedecinJour getCreneauChoisi() {
    return creneauChoisi;
  }

  public void setIdCreneauChoisi(Long idCreneauChoisi) {
    this.idCreneauChoisi = idCreneauChoisi;
  }

  public String getLocale() {
    return locale;
  }

  public String getMsgErreurDate() {
    return msgErreurDate;
  }

  public void setMsgErreurDate(String msgErreurDate) {
    this.msgErreurDate = msgErreurDate;
  }

  public String getStrJour() {
    return strJour;
  }

  public void setStrJour(String strJour) {
    this.strJour = strJour;
  }

  public Boolean getErreurInit() {
    return erreurInit;
  }

  public Boolean getErreurDate() {
    return erreurDate;
  }

  public void setLocale(String locale) {
    this.locale = locale;
  }
  
  
}