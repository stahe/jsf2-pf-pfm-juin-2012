package forms;

import java.util.List;
import javax.faces.model.ListDataModel;
import org.primefaces.model.SelectableDataModel;

public class DataTableModel extends ListDataModel<Personne> implements SelectableDataModel<Personne> {

  // constructeurs
  public DataTableModel() {
  }

  public DataTableModel(List<Personne> personnes) {
    super(personnes);
  }

  @Override
  public Object getRowKey(Personne personne) {
    return personne.getId();
  }

  @Override
  public Personne getRowData(String rowKey) {
    // liste des personnes
    List<Personne> personnes = (List<Personne>) getWrappedData();
    // la clé est un entier 
    int key = Integer.parseInt(rowKey);
    // on recherche la personne sélectionnée
    for (Personne personne : personnes) {
      if (personne.getId() == key) {
        return personne;
      }
    }
    // on n'a rien trouvé
    return null;
  }
}
