package forms;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class Form implements Serializable {

  // modèle
  private List<Personne> personnes;
  private Personne personneChoisie;

  // constructeur
  public Form() {
    // initialisation de la liste des personnes
    personnes = new ArrayList<Personne>();
    personnes.add(new Personne(1, "dupont", "jacques"));
    personnes.add(new Personne(2, "durand", "élise"));
    personnes.add(new Personne(3, "martin", "jacqueline"));
  }

  public void retirerPersonne() {
    // on enlève la personne choisie
    personnes.remove(personneChoisie);
  }

  // getters et setters
  public DataTableModel getPersonnes() {
    return new DataTableModel(personnes);
  }

  public void setPersonneChoisie(Personne personneChoisie) {
    this.personneChoisie = personneChoisie;
  }

  public Personne getPersonneChoisie() {
    return personneChoisie;
  }
}