package forms;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import org.primefaces.context.RequestContext;
import utils.Messages;

@ManagedBean
@SessionScoped
public class Form implements Serializable {

  // modèle
  private List<Personne> personnes;
  private Personne personneChoisie;
  
  // constructeur
  public Form() {
    // initialisation de la liste des personnes
    personnes = new ArrayList<Personne>();
    personnes.add(new Personne(1, "dupont", "jacques"));
    personnes.add(new Personne(2, "durand", "élise"));
    personnes.add(new Personne(3, "martin", "jacqueline"));
  }

  public void retirerPersonne() {
    // suppression aléatoire
    int i = (int) (Math.random() * 2);
    if (i == 0) {
      // on enlève la personne choisie
      personnes.remove(personneChoisie);
    } else {
      // on renvoie une erreur
      String msgErreur = Messages.getMessage(null, "form.msgErreur", null).getSummary();
      RequestContext.getCurrentInstance().addCallbackParam("msgErreur", msgErreur);
    }
  }

  // getters et setters
  public DataTableModel getPersonnes() {
    return new DataTableModel(personnes);
  }

  public void setPersonneChoisie(Personne personneChoisie) {
    this.personneChoisie = personneChoisie;
  }

  public Personne getPersonneChoisie() {
    return personneChoisie;
  }
}