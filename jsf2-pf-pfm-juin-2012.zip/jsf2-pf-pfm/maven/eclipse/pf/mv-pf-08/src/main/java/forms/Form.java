package forms;

import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.model.SelectItem;

@ManagedBean
@SessionScoped
public class Form implements Serializable{
  
  public Form() {
  }
  
// champs du formulaire
  private String combo1="A";
  private String combo2="A1";
  private Integer saisie1=0;
  
  // champs de travail
  final private String[] combo1Labels={"A","B","C"};
  private String combo1Label="A";
  
  // méthodes
  public SelectItem[] getCombo1Items(){
    // init combo1
    SelectItem[] combo1Items=new SelectItem[combo1Labels.length];
    for(int i=0;i<combo1Labels.length;i++){
      combo1Items[i]=new SelectItem(combo1Labels[i],combo1Labels[i]);
    }
    return combo1Items;
  }
  
  public SelectItem[] getCombo2Items(){
    // init combo2 en fonction de combo1
    SelectItem[] combo2Items=new SelectItem[5];
    for(int i=1;i<=combo2Items.length;i++){
      combo2Items[i-1]=new SelectItem(combo1+i,combo1+i);
    }
    return combo2Items;
  }
   
  
// getters - setters
  
  public String getCombo1() {
    return combo1;
  }
  
  public void setCombo1(String combo1) {
    this.combo1 = combo1;
  }
  
  public String getCombo2() {
    return combo2;
  }
  
  public void setCombo2(String combo2) {
    this.combo2 = combo2;
  }
  
  public Integer getSaisie1() {
    return saisie1;
  }
  
  public void setSaisie1(Integer saisie1) {
    this.saisie1 = saisie1;
  }
  
}