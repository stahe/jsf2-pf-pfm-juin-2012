package forms;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class Form implements Serializable {

  private Date calendrier;
  private Integer slider = 100;
  private Integer spinner = 1;
  private String autocompleteValue;

  public Form() {
  }

  public List<String> autocomplete(String query) {
    List<String> results = new ArrayList<String>();

    for (int i = 0; i < 10; i++) {
      results.add(query + i);
    }

    return results;
  }

  public Date getCalendrier() {
    return calendrier;
  }

  public void setCalendrier(Date calendrier) {
    this.calendrier = calendrier;
  }

  public Integer getSlider() {
    return slider;
  }

  public void setSlider(Integer slider) {
    this.slider = slider;
  }

  public Integer getSpinner() {
    return spinner;
  }

  public void setSpinner(Integer spinner) {
    this.spinner = spinner;
  }

  public String getAutocompleteValue() {
    return autocompleteValue;
  }

  public void setAutocompleteValue(String autocompleteValue) {
    this.autocompleteValue = autocompleteValue;
  }
}