package beans;

import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class Form implements Serializable {
  // modèle

  private String inputText = "bonjour";
  private String inputTextArea = "ligne1\nligne2";
  private String selectOneMenu = "2";
  private int range = 4;
  private boolean bswitch = true;
  private boolean booleanCheckbox = false;
  private String[] manyCheckbox = {"1", "3"};
  private String radio = "3";

  public String valider() {
    // on passe à la vue infos
    return "pm:infos";
  }

  public String getManyCheckboxValue() {
    StringBuffer str = new StringBuffer("[");
    for (String checkbox : manyCheckbox) {
      str.append(checkbox);
    }
    str.append("]");
    return str.toString();
  }

  // getters et setters
  public boolean isBooleanCheckbox() {
    return booleanCheckbox;
  }

  public void setBooleanCheckbox(boolean booleanCheckbox) {
    this.booleanCheckbox = booleanCheckbox;
  }

  public boolean isBswitch() {
    return bswitch;
  }

  public void setBswitch(boolean bswitch) {
    this.bswitch = bswitch;
  }

  public String getInputText() {
    return inputText;
  }

  public void setInputText(String inputText) {
    this.inputText = inputText;
  }

  public String getInputTextArea() {
    return inputTextArea;
  }

  public void setInputTextArea(String inputTextArea) {
    this.inputTextArea = inputTextArea;
  }

  public String[] getManyCheckbox() {
    return manyCheckbox;
  }

  public void setManyCheckbox(String[] manyCheckbox) {
    this.manyCheckbox = manyCheckbox;
  }

  public String getRadio() {
    return radio;
  }

  public void setRadio(String radio) {
    this.radio = radio;
  }

  public int getRange() {
    return range;
  }

  public void setRange(int range) {
    this.range = range;
  }

  public String getSelectOneMenu() {
    return selectOneMenu;
  }

  public void setSelectOneMenu(String selectOneMenu) {
    this.selectOneMenu = selectOneMenu;
  }
}
